import pandas as pd
import numpy as np
import matplotlib.pyplot as plt; plt.rcdefaults()
import matplotlib.pyplot as plt
from matplotlib import style

def siteByConnects(df):
    df['Connect']=df['Connect'].convert_objects(convert_numeric=True)	
    aggregations={
               'Connect':'sum'
                      }
               
    df2=df.groupby('SiteName',as_index=False).agg(aggregations)
    
    if(len(df2)<5):
        status="fail"
        return(df2,status)
    else:
        print("Site with maximum no. of connection:\n")
        top10=df2.nlargest(10,'Connect')
        top10=top10.reset_index(drop=True)
        
        
        df3=df2.nlargest(5,'Connect')
        df3=df3.reset_index(drop=True)

        #ploting barchart
        style.use('ggplot')
        plt.clf()
        objects = df3["SiteName"].head(5)
        y_pos = np.arange(len(objects))
        performance = df3["Connect"].head(5)
        plt.barh(y_pos, performance, align='center', alpha=0.5)
        plt.yticks(y_pos, objects)
        plt.xlabel('Connect')
        plt.title('Top 5 Sites by Session')
        plt.tight_layout()
        plt.plot()
        fig=plt.gcf()
        fig.savefig("app/static/charts/siteConnectBar.png",  dpi=150)
        #pie chart
        plt.clf()
        label = (df3["SiteName"].head(5))
        y = (df3["Connect"].head(5))
        plt.pie(y,labels=label,autopct="%1.1f%%")
        fig=plt.gcf()
        fig.savefig("app/static/charts/siteConnectPie.png",  dpi=150)

        status="pass"
        return(top10,status)

def siteByBytes(df):
    aggregations={
               
               'Bytes':'sum'
                   }
               
    df2=df.groupby('SiteName',as_index=False).agg(aggregations)
    
    if(len(df2)<5):
        status="fail"
        return(df2,status)
    else:
        
        top10=df2.nlargest(10,'Bytes')
        top10=top10.reset_index(drop=True)
        
        
        df3=df2.nlargest(5,'Bytes')
        df3=df3.reset_index(drop=True)
        style.use('ggplot')
        plt.clf()
        objects = df3["SiteName"].head(5)
        y_pos = np.arange(len(objects))
        performance = df3["Bytes"].head(5)
        plt.barh(y_pos, performance, align='center', alpha=0.5)
        plt.yticks(y_pos, objects)
        plt.xlabel('Bytes')
        plt.title('Top 5 Sites by Data Usage')
        plt.tight_layout()
        plt.plot()
        fig=plt.gcf()
        fig.savefig("app/static/charts/siteBytesBar.png",  dpi=150)
        #pie chart
        plt.clf()
        label = (df3["SiteName"].head(5))
        y = (df3["Bytes"].head(5))
        plt.pie(y,labels=label,autopct="%1.1f%%")
        fig=plt.gcf()
        fig.savefig("app/static/charts/siteBytesPie.png",  dpi=150)
        status="pass"
        for index,row in top10.iterrows():
            top10['Bytes'][index]= round(top10['Bytes'][index]/(1024*1024),4)
        return(top10,status)

def siteByElapseTime(df):

    df['ElapseTime'] = pd.to_timedelta(df['ElapseTime'])
    aggregations={
               'ElapseTime':'sum'         }
               
    df1=df.groupby('SiteName',as_index=False).agg(aggregations)
    if(len(df1)<5):
        status="fail"
        return(df1,status)
    else:
        
        top10=df1.nlargest(10,'ElapseTime')
        top10=top10.reset_index(drop=True)
        status="pass"
        return(top10,status)