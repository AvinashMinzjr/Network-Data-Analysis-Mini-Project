import re
import pandas as pd

def areaFinder(df, area):
	#range for admin 10.10.0.0 - 10.10.7.256
	admin_pattern= re.compile(r'^10.10.[0-7].*$')

	#range for som 10.10.8.0 - 10.10.15.256
	som_pattern= re.compile(r'^10.10.1[0-5].*$')

	#range for library 10.10.16.0 - 10.10.19.256
	library_pattern= re.compile(r'^10.10.1[6-9].*$')

	#range for kamban 10.10.20.0 - 10.10.23.256
	kamban_pattern= re.compile(r'^10.10.2[0-3].*$')

	#range for kavery 10.10.24.0 - 10.10.27.256
	kavery_pattern= re.compile(r'^10.10.2[4-7].*$')

	#range for voice 10.10.28.0 - 10.10.31.256
	voice_pattern= re.compile(r'^10.10.(2[8-9])|(3[0-1]).*$')

	#range for sb-II 10.10.32.0 - 10.10.47.256
	sbII_pattern= re.compile(r'^10.10.(3[2-9])|(4[0-7]).*$')

	#range for soss 10.10.48.0 - 10.10.63.256
	soss_pattern1= re.compile(r'^10.10.(4[7-9])|(5[0-9]).*$')
	soss_pattern2= re.compile(r'^10.10.6[0-3].\d+$')

	#range for wireless 10.10.64.0 - 10.10.87.256
	wireless_pattern1= re.compile(r'^10.10.(6[4-9])|(7[0-9]).*$')
	wireless_pattern2= re.compile(r'^10.10.8[0-7].\d+$')

	#range for static 10.10.88.0 - 10.10.256.256
	static_pattern= re.compile(r'^10.10.8[0-9].*$')

	admin_df=pd.DataFrame(columns=('SourceIp','SiteName','Connect','Bytes','ElapseTime'))

	som_df=admin_df
	library_df=admin_df
	kamban_df=admin_df
	kavery_df=admin_df
	voice_df=admin_df
	sbII_df=admin_df
	soss_df=admin_df
	wireless_df=admin_df
	static_df=admin_df

	admin_counter=0
	som_counter=0
	library_counter=0
	kamban_counter=0
	kavery_counter=0
	voice_counter=0
	sbII_counter=0
	soss_counter=0
	wireless_counter=0
	static_counter=0

	for index,row in df.iterrows():
		ip=df['SourceIp'][index]

		if re.match(admin_pattern,ip) and (area=='admin'):
			admin_df.loc[admin_counter]=(df.loc[index])
			admin_counter+=1
		elif re.match(som_pattern,ip) and (area=='som'):
			som_df.loc[som_counter]=(df.loc[index])
			som_counter+=1
		elif re.match(library_pattern,ip) and (area=='library'):
			library_df.loc[library_counter]=(df.loc[index])
			library_counter+=1
		elif re.match(kamban_pattern,ip) and (area=='kamban'):
			kamban_df.loc[kamban_counter]=(df.loc[index])
			kamban_counter+=1
		elif re.match(kavery_pattern,ip) and (area=='kavery'):
			kavery_df.loc[kavery_counter]=(df.loc[index])
			kavery_counter+=1
		elif re.match(voice_pattern,ip) and (area=='voice'):
			voice_df.loc[voice_counter]=(df.loc[index])
			voice_counter+=1
		elif re.match(sbII_pattern,ip) and (area=='sbII'):
			sbII_df.loc[sbII_counter]=(df.loc[index])
			sbII_counter+=1
		elif re.match(soss_pattern1,ip) or re.match(soss_pattern2,ip) and (area=='soss'):
			soss_df.loc[soss_counter]=(df.loc[index])
			soss_counter+=1
		elif re.match(wireless_pattern1,ip) or re.match(wireless_pattern2,ip) and (area=='wireless'):
			wireless_df.loc[wireless_counter]=(df.loc[index])
			wireless_counter+=1
		elif re.match(static_pattern,ip) and (area=='static'):
			static_df.loc[static_counter]=(df.loc[index])
			static_counter+=1

	if (area=='admin'):
		return(admin_df)
	elif (area=='som'):
		return(som_df)
	elif (area=='library'):
		return(library_df)
	elif (area=='kamban'):
		return(kamban_df)
	elif (area=='kavery'):
		return(kavery_df)
	elif (area=='voice'):
		return(voice_df)
	elif (area=='sbII'):
		return(sbII_df)
	elif (area=='soss'):
		return(soss_df)
	elif (area=='wireless'):
		return(wireless_df)
	elif (area=='static'):
		return(static_df)

