import numpy as np
import matplotlib.pyplot as plt; plt.rcdefaults()
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib import style


def topIpByConnects(df):
    
    df['Connect']=df['Connect'].convert_objects(convert_numeric=True)
        
    aggregations={
               'Connect':'sum'
                     }
               
    df1=df.groupby('SourceIp',as_index=False).agg(aggregations)
    
    if(len(df1)<5):
        status="fail"
        return(df1,status)
    else:
        
        top10=df1.nlargest(10,'Connect')
        top10=top10.reset_index(drop=True)
        
        
        df2=df1.nlargest(5,'Connect')
        df2 = df2.reset_index(drop=True)

        #ploting barchart
        style.use('ggplot')
        plt.clf()
        objects = df2["SourceIp"].head(5)
        y_pos = np.arange(len(objects))
        performance = df2["Connect"].head(5)
        plt.barh(y_pos, performance, align='center', alpha=0.5)
        plt.yticks(y_pos, objects)
        plt.xlabel('connects')
        plt.title('Top 5 Users by Session')
        plt.tight_layout()
        fig1=plt.gcf()
        fig1.savefig("app/static/charts/ipConnectBar.png",  dpi=150)
        
        #pie chart
        plt.clf()
        label = (df2["SourceIp"].head(5))
        y = (df2["Connect"].head(5))
        plt.pie(y,labels=label,autopct="%1.1f%%")
        fig=plt.gcf()
        plt.draw()
        fig.savefig("app/static/charts/ipConnectpie.png",  dpi=150)

        status="pass"

        return(top10,status)

def topIpByBytes(df):
    aggregations={
               'Bytes':'sum'
                       }
    df['Bytes']=df['Bytes'].convert_objects(convert_numeric=True)
               
    df1=df.groupby('SourceIp',as_index=False).agg(aggregations)
    if(len(df1)<5):
        status="fail"
        return(df1,status)
    else:
        top10=df1.nlargest(10,'Bytes')
        top10=top10.reset_index(drop=True)

        
        df2=df1.nlargest(5,'Bytes')
        df2 = df2.reset_index(drop=True)

        style.use('ggplot')
        plt.clf()
        objects = df2["SourceIp"].head(5)
        y_pos = np.arange(len(objects))
        performance = df2["Bytes"].head(5)
        plt.barh(y_pos, performance, align='center', alpha=0.5)
        plt.yticks(y_pos, objects)
        plt.xlabel('Data Usage')
        plt.title('Top 5 Users by Data Usage')
        plt.tight_layout()
        fig2=plt.gcf()
        fig2.savefig("app/static/charts/ipBytesBar.png",  dpi=150)
        
        #pie chart
        plt.clf()
        label = (df2["SourceIp"].head(5))
        y = (df2["Bytes"].head(5))
        plt.pie(y,labels=label,autopct="%1.1f%%")
        fig=plt.gcf()
        plt.draw()
        fig.savefig("app/static/charts/ipBytespie.png",  dpi=150)

        status="pass"
        for index,row in top10.iterrows():
            top10['Bytes'][index]= round(top10['Bytes'][index]/(1024*1024),4)

        return(top10,status)

def topIpByElapseTime(df):

    df['ElapseTime'] = pd.to_timedelta(df['ElapseTime'])
    aggregations={
               'ElapseTime':'sum'         }
               
    df1=df.groupby('SourceIp',as_index=False).agg(aggregations)
    if(len(df1)<5):
        status="fail"
        return(df1,status)
    else:
        
        top10=df1.nlargest(10,'ElapseTime')
        top10=top10.reset_index(drop=True)
        status="pass"
        return(top10,status)
