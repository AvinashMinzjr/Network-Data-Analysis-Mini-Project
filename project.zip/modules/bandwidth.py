import pandas as pd

def bandwidthAnalyse(df):

	total_usr = ((df["SourceIp"].unique())).tolist()
	user_count=len(total_usr)

	total_site = df["SiteName"].tolist()
	site_count = len(total_site)

	total_bytes = df["Bytes"].tolist()
	bytes_count= sum(total_bytes)

	bytes_count=round(bytes_count/(1024*1024),2)


	return (user_count,site_count,bytes_count)