from django.shortcuts import render
from django.shortcuts import HttpResponse
from django.core.exceptions import *
import pandas as pd

#importing modules
from modules.bandwidth import *
from modules.ipbased import *
from modules.sitebased import *
from modules.areafinder import *

def index(request):

	if request.method =='POST':

		
		file = request.FILES["file"]
		region = request.POST["area"]
		report_type = request.POST["report_type"]
		df = pd.read_csv(file)

		if (region=='all' and  report_type=='bandwidth'):

			user_count,site_count,bytes_count= bandwidthAnalyse(df)
			contex = {'area':region ,'report_type':report_type, 'user_count':user_count,'site_count':site_count,'bytes_count':bytes_count}
			return render(request, 'bandwidth_report.html',contex)
		
		if (report_type=='bandwidth' and region!='all'):
			df=areaFinder(df, region)
			user_count,site_count,bytes_count= bandwidthAnalyse(df)
			contex = {'area':region ,'report_type':report_type, 'user_count':user_count,'site_count':site_count,'bytes_count':bytes_count}
			return render(request, 'bandwidth_report.html',contex)

		elif (region=='all' and  report_type=='ip'):
			
			list_by_time,status = topIpByElapseTime(df)
			list_by_connect,status = topIpByConnects(df)
			list_by_bytes,status = topIpByBytes(df)

			list_by_bytes=list(list_by_bytes.values) 
			list_by_connect = list(list_by_connect.values)
			list_by_time=list(list_by_time.values)
			#images
			connect_bar='charts/ipConnectBar.png'
			bytes_bar='charts/ipBytesBar.png'

			

			context = {'status':status,'report_type':'IP Address','list_by_bytes':list_by_bytes,'list_by_connect':list_by_connect,'list_by_time':list_by_time,'connect_bar':connect_bar,'bytes_bar':bytes_bar}
			return render(request, 'report.html', context)

		elif (region=='all' and  report_type=='site'):

			list_by_time,status = siteByElapseTime(df)
			list_by_connect,status = siteByConnects(df)
			list_by_bytes,status = siteByBytes(df)

			list_by_bytes=list(list_by_bytes.values) 
			list_by_connect = list(list_by_connect.values)
			list_by_time=list(list_by_time.values)

			connect_bar='charts/siteConnectBar.png'
			bytes_bar='charts/siteBytesBar.png'

			context = {'status':status,'report_type':'Website','list_by_bytes':list_by_bytes,'list_by_connect':list_by_connect,'list_by_time':list_by_time,'connect_bar':connect_bar,'bytes_bar':bytes_bar}
			return render(request, 'report.html', context)

		elif (report_type=='ip'):
			df=areaFinder(df, region)
			list_by_time,status = topIpByElapseTime(df)
			list_by_connect,status = topIpByConnects(df)
			list_by_bytes,status = topIpByBytes(df)

			list_by_bytes= list(list_by_bytes.values) 
			list_by_connect = list(list_by_connect.values)
			list_by_time=list(list_by_time.values)
			#images
			connect_bar='charts/ipConnectBar.png'
			bytes_bar='charts/ipBytesBar.png'

			

			context = {'status':status,'report_type':'IP Address','list_by_bytes':list_by_bytes,'list_by_connect':list_by_connect,'list_by_time':list_by_time,'connect_bar':connect_bar,'bytes_bar':bytes_bar}
			return render(request, 'report.html', context)

		elif (report_type=='site'):
			df=areaFinder(df, region)
			list_by_time,status = siteByElapseTime(df)
			list_by_connect,status = siteByConnects(df)
			list_by_bytes,status = siteByBytes(df)

			list_by_bytes=list(list_by_bytes.values) 
			list_by_connect = list(list_by_connect.values)
			list_by_time=list(list_by_time.values)

			connect_bar='charts/siteConnectBar.png'
			bytes_bar='charts/siteBytesBar.png'

			context = {'status':status,'report_type':'Website','list_by_bytes':list_by_bytes,'list_by_connect':list_by_connect,'list_by_time':list_by_time,'connect_bar':connect_bar,'bytes_bar':bytes_bar}
			return render(request, 'report.html', context)



	else:
		return render(request, 'index.html')


